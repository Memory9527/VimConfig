<?php
namespace app\models;

use corephp\base\Model;

class AdminModel extends Model {
//user数据表
    protected $table = 'user';
}