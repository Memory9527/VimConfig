<?php
namespace app\models;

use corephp\base\Model;

/**
 * 友情链接Model
 * 管理blog的友链数据库
 */
class FlinkModel extends  Model{

    protected $table = 'flink';


}