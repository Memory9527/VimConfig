<?php
namespace app\models;

use corephp\base\Model;
/**
 * 栏目Model
 * 管理blog的栏目数据库
 */
class CategoryModel extends  Model{

    protected $table = 'cat';


}