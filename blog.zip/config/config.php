<?php
//数据库配置
$config['db']['host'] = 'localhost';
$config['db']['username'] = 'root';
$config['db']['password'] = 'windows@123';
$config['db']['dbname'] = 'blog';

//默认控制器和操作名
$config['defaultController'] = 'article';
$config['defaultAction'] = 'article';

return $config;